/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package herencia;

/**
 *
 * @author J3 PC20
 */
public class entrenador extends seleccion{
    
    String idFederacion;
    
    public entrenador(){
        super();
    }

    public entrenador(String idFederacion, int id, String nombre, String apellido, int edad) {
        super(id, nombre, apellido, edad);
        this.idFederacion = idFederacion;
    }

    public String getidFederacion(){
    return idFederacion;
    }
    
    public void setidFederacion(String idFederacion){
    this.idFederacion = idFederacion;
    }    
    
    public void dirigirPartido(){
        
    }    
    
    public void dirijirEntrenamiento(){
    
    } 
}
