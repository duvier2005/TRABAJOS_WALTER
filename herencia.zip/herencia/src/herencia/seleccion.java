/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package herencia;

/**
 *
 * @author J3 PC20
 */
public class seleccion {
    
    protected int id;
    protected String nombre;
    protected String apellido;
    protected int edad;
    
    public seleccion(){
    
    }

    public seleccion(int id, String nombre, String apellido, int edad) {
        this.id = id;
        this.nombre = nombre;
        this.apellido = apellido;
        this.edad = edad;
    }
    
    public int getid(){
    return id;
    }
    
    public void setid(int id){
    this.id = id;
    }

    public String getnombre(){
    return nombre;
    }
    
    public void setnombre(String nombre){
    this.nombre = nombre;
    }
    
    public String getapellido(){
    return apellido;
    }
    
    public void setapellido(String apellido){
    this.apellido = apellido;
    }   

    public int getedad(){
    return edad;
    }
    
    public void setedad(int edad){
    this.edad = edad;
    }

    public void concenrase(){
    
        System.out.println("consentrarse");
        
    }
    
    public void viajar(){
    
        System.out.println("viajar");
        
    }    
}

