/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package herencia;

/**
 *
 * @author J3 PC20
 */
public class masajista extends seleccion{
    
    String titulacion;
    Integer añosExperiencia;
    
    public masajista(){
        super();
    }    

    public masajista(String titulacion, Integer añosExperiencia, int id, String nombre, String apellido, int edad) {
        super(id, nombre, apellido, edad);
        this.titulacion = titulacion;
        this.añosExperiencia = añosExperiencia;
    }

    public String gettitulacion(){
    return titulacion;
    }
    
    public void settitulacion(String titulacion){
    this.titulacion = titulacion;
    }    
    
    public Integer getañosExperiencia(){
    return añosExperiencia;
    }
    
    public void setañosExperiencia(Integer añosExperiencia){
    this.añosExperiencia = añosExperiencia;
    }    
    
    public void darMasaje(){
        System.out.println("dar masajes");
    
    }
}
