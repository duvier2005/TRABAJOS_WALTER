/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package herencia;

/**
 *
 * @author J3 PC20
 */
public class futbolista extends seleccion{
    
    int dorsal;
    String demarcacion;
    
    public futbolista(){
        super();        
    
    }

    public futbolista(int dorsal, String demarcacion, int id, String nombre, String apellido, int edad) {
        super(id, nombre, apellido, edad);
        this.dorsal = dorsal;
        this.demarcacion = demarcacion;
    }
    
    public int getdorsal(){
    return dorsal;
    }
    
    public void setdorsal(int dorsal){
    this.dorsal = dorsal;
    }
    
    public String getdemarcacion(){
    return demarcacion;
    }
    
    public void setdemarcacion(String demarcacion){
    this.demarcacion = demarcacion;
    }
    
    public void jugarPartido(){
        
    }
    
    public void entrenar(){
     
    }    
    
    @Override
    
    public void viajar(){
        System.out.println("el futbolista viajara");
    }
    
    public void concentarse(){
        System.out.println("el futbolista se consentrara");
    }    
}
