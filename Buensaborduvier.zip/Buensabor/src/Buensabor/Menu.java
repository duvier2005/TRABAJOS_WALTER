/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package Buensabor;
import javax.swing.JOptionPane;
import java.util.Scanner;
public class Menu {


    public static void main(String[] args) {
    Scanner teclado = new Scanner(System.in);
    
    String aparecerM;
    int Menu;
    double descuento = 0, adicion = 0, total = 0;
    Comidas op = new Comidas();
    
        System.out.println("desea el menu? (ingrese si o no )");
        aparecerM = teclado.next();
        
        switch (aparecerM){
        case "Si" : case "SI" : case "si" :
                System.out.println("    menu                  precio     adiciones                  descuento    ");
                System.out.println("");
                
                System.out.println("1. Bandeja paisa          25.000     chicharron/chorizo         10%      ");
                System.out.println("2. Mondongo               20.000     ensalada/aguacate          15%      ");
                System.out.println("3. Sancocho de cerdo      25.000     ensalada/aguacate          10%      ");
                System.out.println("4. Menu del dia           20.000     N/A                        N/A      ");

                System.out.println("que desea ordenar: ");
        
                Menu = teclado.nextInt();
                switch(Menu){
                    
                    case 1:
                        op.paisa(total, descuento, adicion);
                        break;
                        
                    case 2:
                        op.mondongo(total, descuento, adicion);
                        break;
                        
                    case 3:
                        op.sopa_cerdo(total, descuento, adicion);
                        break;    
                        
                    case 4:
                        op.menu_dia(total, descuento, adicion);
                        break;    
                }        
        }                           
    }    
}
