/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio3;

/**
 *
 * @author J3 PC20
 */
import java.util.Scanner;
public class Ejercicio3 {


    public static void main(String[] args) {
        Scanner entrada = new Scanner (System.in);
        
        
        String clavecorrecta = "duvier54321";
        
        System.out.print("integrasa tu contraseña:");
        String claveingresada = entrada.nextLine();
        
        
        
        if (claveingresada.equals(clavecorrecta)) {
            System.out.println("Bienvenido Acceso permitido");
        } else {
            System.out.println("contraseña incorrecta Acceso denegado.");
            
        }
        
    }
    
}
