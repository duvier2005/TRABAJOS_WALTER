/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio2;

/**
 *
 * @author J3 PC20
 */
import java.util.Scanner;
public class Ejercicio2 {

  
    public static void main(String[] args) {
        Scanner entrada = new Scanner (System.in);
        int numero = 0;
        
        
        System.out.println (numero + "Ingresa el numero");
        numero = entrada.nextInt();
        
        
        if (numero % 2 == 0) {
            System.out.println(numero + "El numero es par");
        }
        else if (numero % 2 > 0){
            System.out.println(numero + "el numero es impsr");
        }
       
    }
    
}