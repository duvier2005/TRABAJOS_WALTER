/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio5;

/**
 *
 * @author J3 PC20
 */
import java.util. Scanner;
public class Ejercicio5 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner entrada = new Scanner (System.in);
        
        int numero1 = 0;
        int numero2 = 0;
        int operacion = 0;
        int resultado = 0;
        
        System.out.println("elige la operacion a realizar segun los siguientes valores suma(1) resta(2) multiplicacion(3) divicion(4) ");
        operacion = entrada.nextInt();
        
        System.out.println("ingresa el primer numero: ");
        numero1 = entrada.nextInt();
        
        System.out.println("ingresa el segudo numero: ");
        numero2 = entrada.nextInt();
        
        switch (operacion){
            case 1: resultado = numero1 + numero2;
                System.out.println("el resultado de la suma es: " + resultado);
                break;
                
            case 2: resultado = numero1 - numero2;
                System.out.println("el resultado de la resta es: " + resultado);
                break; 
                
            case 3: resultado = numero1 * numero2;
                System.out.println("el resultado de la multiplicion es: " + resultado);
                break;
                
            case 4: resultado = numero1 / numero2;
                System.out.println("el resultado de la divicion es: " + resultado);
                break;
                
            default: System.out.println("error, la operacion no existe");
                break;
        }
    }
    
}
