/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio9;

/**
 *
 * @author J3 PC20
 */
import java.util.Scanner;

public class Ejercicio9 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Ingrese un año: ");
        int año = sc.nextInt();

        if (año % 4 == 0) {
            if (año % 100 == 0) {
                if (año % 400 == 0) {
                    System.out.println("El año es bisiesto");
                } else {
                    System.out.println("El año no es bisiesto");
                }
            } else {
                System.out.println("El año es bisiesto");
            }
        } else {
            System.out.println("El año no es bisiesto");
        }
    }
}
