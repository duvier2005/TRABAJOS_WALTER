/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio10;

/**
 *
 * @author J3 PC20
 */
import java.util.Scanner;

public class Ejercicio10 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.println("1. Moto");
        System.out.println("2. Carro");
        System.out.println("3. Autobús");

        System.out.print("Seleccione el vehículo: ");
        int vehiculo = sc.nextInt();

        System.out.print("Ingrese las horas: ");
        int horas = sc.nextInt();

        double tarifa = 0;

        switch (vehiculo) {
            case 1:
                tarifa = 2000;
                break;
            case 2:
                tarifa = 4000;
                break;
            case 3:
                tarifa = 6000;
                break;
            default:
                System.out.println("Vehículo inválido");
                return;
        }

        double total;

        if (horas > 8) {
            total = (8 * tarifa) + 5000;
        } else {
            total = horas * tarifa;
        }

        System.out.println("Total a pagar: $" + total);
    }
}
