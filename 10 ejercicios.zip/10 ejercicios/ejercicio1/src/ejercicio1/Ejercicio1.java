/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio1;

/**
 *
 * @author J3 PC20
 */
import java.util.Scanner;
public class Ejercicio1 {


    public static void main(String[] args) {
        Scanner entrada = new Scanner (System.in);
        int edad = 0;
        
        System.out.println("ingrese su edad: ");
        edad = entrada.nextInt();
        
        if (edad >= 18){
            System.out.println("acceso concedido");
        }
        else if (edad < 18){
            System.out.println("acceso denegado");
            
        }
    }
}
    
    

