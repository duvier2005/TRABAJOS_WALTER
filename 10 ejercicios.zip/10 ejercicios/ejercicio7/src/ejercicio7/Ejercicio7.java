/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio7;

/**
 *
 * @author J3 PC20
 */
import java.util.Scanner;

public class Ejercicio7 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Ingrese un mes: ");
        String mes = sc.nextLine();

        switch (mes.toLowerCase()) {
            case "diciembre":
            case "enero":
            case "febrero":
                System.out.println("Invierno");
                break;

            case "marzo":
            case "abril":
            case "mayo":
                System.out.println("Primavera");
                break;

            case "junio":
            case "julio":
            case "agosto":
                System.out.println("Verano");
                break;

            case "septiembre":
            case "octubre":
            case "noviembre":
                System.out.println("Otoño");
                break;

            default:
                System.out.println("Mes inválido");
        }
    }
}
