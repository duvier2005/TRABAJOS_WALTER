/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio8;

/**
 *
 * @author J3 PC20
 */
import java.util.Scanner;

public class Ejercicio8 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Ingrese el precio total: ");
        double precio = sc.nextDouble();

        System.out.print("Ingrese el tipo de membresía (A, B o C): ");
        char membresia = sc.next().toUpperCase().charAt(0);

        double descuento = 0;

        switch (membresia) {
            case 'A':
                descuento = 0.10;
                break;
            case 'B':
                descuento = 0.15;
                break;
            case 'C':
                descuento = 0.20;
                break;
            default:
                System.out.println("Membresía inválida");
                return;
        }

        double total = precio - (precio * descuento);

        if (precio > 100) {
            total = total - (total * 0.05);
        }

        System.out.println("Total a pagar: $" + total);
    }
}
