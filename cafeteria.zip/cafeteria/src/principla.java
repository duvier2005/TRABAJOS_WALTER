/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */

/**
 *
 * @author J3 PC20
 */
public class principla {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        cafetera micafetera = new cafetera("oster", "negro");       
    
        micafetera.prepararcafe();
    
    }
    
}
