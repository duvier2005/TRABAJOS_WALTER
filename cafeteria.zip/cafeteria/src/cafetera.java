/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author J3 PC20
 */
public class cafetera {
    
    String marca ;
    String color ;

    public cafetera(String marca, String color) {
        this.marca = marca;
        this.color = color;
    }
    
    public void prepararcafe(){
        
        System.out.println("1. calentando cafe 90°...");
        System.out.println("2. filtrando el agua a traves del cafe...");
        System.out.println("3. el cafe est listo, cuidado te quemas");
    
    
    }
   
}
