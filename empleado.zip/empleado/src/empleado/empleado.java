/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package empleado;

import javax.swing.JOptionPane;
import java.util.Scanner;

public class empleado {
    
    String nombre;
    String cedula;
    double horasTrabajadas; 
    double valorHora;

    public empleado(String nombre, String cedula, double horasTrabajadas, double valorHora) {
        this.nombre = nombre;
        this.cedula = cedula;
        this.horasTrabajadas = horasTrabajadas;
        this.valorHora = valorHora;
    }

    public double calcularPago(){
        Scanner entrada = new Scanner (System.in);
        int nombre = 0;
        int cedula = 0;
        int horasTrabajadas = 0;
        int valorHora = 25000;
        
        
        if (this.horasTrabajadas > 80){
            System.out.println("recardo de 25%" + (this.horasTrabajadas+this.valorHora*0.25) );
            }
        else if (this.horasTrabajadas <= 80){
            System.out.println("sin recargo" + this.horasTrabajadas*this.valorHora);
            }
    }    
    
    
    public String evaluarJornada(){
        Scanner entrada = new Scanner (System.in);
        int nombre = 0;
        int cedula = 0;
        int horasTrabajadas = 0;
        int valorHora = 25000;
        

        if (horasTrabajadas > 80){
            System.out.println("jornada con horas extras");
        }
           
        else if (horasTrabajadas >= 60){
            System.out.println("jornada completa");
        }    
        
        else if (horasTrabajadas < 60){
            System.out.println("jornada incompleta ");  
        }
    } 
    
    public void mostrarInformacion(){
        System.out.println("nombre: " + nombre);
        System.out.println("cedula: " + cedula);
        System.out.println("horasTrabajadas: " + horasTrabajadas);
        System.out.println("valorHora: " + valorHora);
       
    }
}