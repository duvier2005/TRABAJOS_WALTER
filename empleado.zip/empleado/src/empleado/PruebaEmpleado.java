/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package empleado;

import javax.swing.JOptionPane;
import java.util.Scanner;

public class PruebaEmpleado {


    public static void main(String[] args) {
        Scanner entrada = new Scanner (System.in);
        
        empleado empleado1 = new empleado("miguel", "10236", 81, 25000 ); 
        empleado empleado2 = new empleado("duvier", "95484", 54, 25000);
        empleado empleado3 = new empleado("alejandro", "10236", 60, 25000 ); 
        empleado empleado4 = new empleado("pedro", "10236", 80, 25000 ); 
   
        System.out.println("=== empleado 1 ===");
        
        empleado1.mostrarInformacion();
        
        System.out.println("pago del mes: " + empleado1.calcularPago());
        
        System.out.println();        
        

        System.out.println("=== empleado 2 ===");
        
        empleado1.mostrarInformacion();
        
        System.out.println("pago del mes: " + empleado1.calcularPago());
        
        System.out.println();        

        
        System.out.println("=== empleado 3 ===");
        
        empleado1.mostrarInformacion();
        
        System.out.println("pago del mes: " + empleado1.calcularPago());
        
        System.out.println();        
        
        
        System.out.println("=== empleado 4 ===");
        
        empleado1.mostrarInformacion();
        
        System.out.println("pago del mes: " + empleado1.calcularPago());
        
        System.out.println();        

    }
    
}
