    /*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */

/**
 *
 * @author J3 PC20
 */
public class principal {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        producto producto1 = new producto("p001", "carro", 50000); 
        producto producto2 = new producto("p002", "moto", 40000); 
   
        System.out.println("=== PRODUCTO 1 ===");
        
        producto1.mostrarInformacion();
        
        System.out.println("precio con descuento: " + producto1.calcularDescuento());
        
        System.out.println();
        
        
        System.out.println("=== PRODUCTO 2 ===");
        
        producto2.mostrarInformacion();
        
        System.out.println("precio con descuento: " + producto2.calcularDescuento());
    }
    
}
