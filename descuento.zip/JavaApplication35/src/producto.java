/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author J3 PC20
 */
public class producto {
    
    String codigo ;
    String nombre ;
    double precio ; 
    

    public producto(String codigo, String nombre, double precio) {
        
        this.codigo = codigo;
        this.nombre = nombre;
        this.precio = precio;
    }
    
    public void mostrarInformacion(){
    
        System.out.println("codigo: " + codigo);
        System.out.println("nombre: " + nombre);
        System.out.println("precio: " + precio);
    
    }
            
    public double calcularDescuento() {
        
        return precio - (precio * 0.10);
    

    
    }
}
